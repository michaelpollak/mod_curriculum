<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     mod_curriculum
 * @category    string
 * @copyright   2026 michaelpollak <moodle@michaelpollak.org>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Curriculum';
$string['modulename'] = 'Curriculum';
$string['modulenameplural'] = 'Curricula';
$string['curriculumname'] = 'Name';
$string['curriculumname_help'] = 'Name of the curriculum or curricula.';
$string['currviews'] = 'Views'; // Ansichten.
$string['currviews_areas'] = 'Areas'; // Bereiche.
$string['currviews_objectives'] = 'Objectives'; //  Bausteine.
$string['logviews'] = 'Logbooks';
$string['kanviews'] = 'Kanbans';
$string['currselect'] = 'Select view';

$string['pluginadministration'] = 'Administration';
$string['serveroffline'] = 'The server seems to be offline or configured incorrectly.';

// Admin settings.
$string['clientid'] = 'client_id';
$string['clientid_text'] = 'Add the SSO client ID here.';
$string['clientsecret'] = 'client_secret';
$string['clientsecret_text'] = 'Add the SSO client secret here.';
$string['clientssl'] = 'Use SSL';
$string['clientssl_text'] = 'Use SSL encryption to the curriculum server.';
$string['serverurl'] = 'Serverurl';
$string['serverurl_text'] = 'Add the url of the Curriculum server.';
$string['servertimeout'] = 'Servertimeout';
$string['servertimeout_text'] = 'Change the timeout for slower servers.';
$string['commonname'] = 'Common Name';
$string['commonname_text'] = 'Leave blank in production, for testing any common name can be added.';
$string['gettoken'] = 'Enable get_token';
$string['gettoken_text'] = 'Leave blank if you don\' t use the get_token feature.';

// Modform.
$string['logbook'] = 'Logbook';
$string['kanban'] = 'Kanban';
$string['curricula'] = 'Curricula';

$string['linkcurriculum'] = 'Open the curriculum {$a} in this window.';
$string['linklogbook'] = 'Open {$a} in a new tab';
$string['linkkanban'] = 'Open {$a} in a new tab';

$string['curriculum:addinstance'] = 'Add a new instance';
$string['exactlyone'] = 'Choose exactly one curriculum to select specific areas and objectives.';

$string['links'] = 'Link';
$string['triggeractivity'] = 'Triggeractivity';
$string['triggerobjectives'] = 'Triggerobjectives';
$string['triggeractivity_help'] = 'If needed select an activity that is linked.';

$string['threshold'] = 'Thresholds'; 
$string['threshold_help'] = 'Assignment grades that translate to curriculum color codes, defaults to 90,70,50.';

// Exceptions.
$string['pleaselogin'] = 'You have to be logged in to Moodle.';
$string['askadmin'] = 'This feature was disabled by the admin.';
$string['notoken'] = 'There is no token set up for this user.';