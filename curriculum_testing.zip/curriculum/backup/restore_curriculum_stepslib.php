<?php
defined('MOODLE_INTERNAL') || die();

class restore_curriculum_activity_structure_step extends restore_activity_structure_step {

    protected function define_structure() {
        $paths = [];
        $userinfo = $this->get_setting_value('userinfo');

        $paths[] = new restore_path_element('curriculum', '/activity/curriculum');
        if ($userinfo) {
            $paths[] = new restore_path_element('curriculum_link', '/activity/curriculum/links/link');
        }

        return $this->prepare_activity_structure($paths);
    }

    protected function process_curriculum($data) {
        global $DB;

        $data = (object)$data;
        $data->course = $this->get_courseid();

        $newid = $DB->insert_record('curriculum', $data);
        $this->apply_activity_instance($newid);
    }

    protected function process_curriculum_link($data) {
        global $DB;

        $data = (object)$data;

        // Kurs richtig mappen.
        $data->course = $this->get_courseid();
        if (!empty($data->usermodified)) {
            $data->usermodified = $this->get_mappingid('user', $data->usermodified);
            $data->cmid = $data->cmid; // wir nehmen an dass die quiz ids gleich bleiben.
        }

        $DB->insert_record('curriculum_links', $data);
    }

    protected function after_execute() {
        // Files wiederherstellen.
        $this->add_related_files('mod_curriculum', 'intro', null);
    }
}
