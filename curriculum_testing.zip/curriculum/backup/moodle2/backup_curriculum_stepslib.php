<?php
defined('MOODLE_INTERNAL') || die();

class backup_curriculum_activity_structure_step extends backup_activity_structure_step {

    protected function define_structure() {
        $userinfo = $this->get_setting_value('userinfo');

        $curriculum = new backup_nested_element('curriculum', ['id'], [
            'course',
            'name',
            'timecreated',
            'timemodified',
            'intro',
            'introformat',
            'curriculum_elements',
            'curriculum_elements_areas',
            'curriculum_elements_objectives',
            'logbook_elements',
            'kanban_elements',
            'curriculum_triggeractivity',
            'curriculum_triggerobjectives',
            'threshold'
            'thresholdyellow'
        ]);

        $links = new backup_nested_element('links');
        $link  = new backup_nested_element('link', ['id'], [
            'course',
            'cmid',
            'activityid',
            'bausteinid',
            'usermodified',
            'timecreated',
            'timemodified'
        ]);

        $curriculum->add_child($links);
        $links->add_child($link);

        $curriculum->set_source_table('curriculum', ['id' => backup::VAR_ACTIVITYID]);

        if ($userinfo) {
            $link->set_source_table('curriculum_links', [
                'course' => backup::VAR_COURSEID,
                'cmid'   => backup::VAR_MODID
            ]);
        }

        $curriculum->annotate_ids('course', 'course');
        $link->annotate_ids('course', 'course');
        $link->annotate_ids('user', 'usermodified');

        $curriculum->annotate_files('mod_curriculum', 'intro', null);

        return $this->prepare_activity_structure($curriculum);
    }
}
