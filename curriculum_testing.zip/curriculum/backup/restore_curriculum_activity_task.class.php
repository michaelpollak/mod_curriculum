<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/curriculum/backup/moodle2/restore_curriculum_stepslib.php');

class restore_curriculum_activity_task extends restore_activity_task {

    protected function define_my_steps() {
        $this->add_step(new restore_curriculum_activity_structure_step('curriculum_structure', 'curriculum.xml'));
    }

    public static function define_decode_contents() {
        $contents = [];
        $contents[] = new restore_decode_content('curriculum', ['intro'], 'curriculum');
        return $contents;
    }

    public static function define_decode_rules() {
        $rules = [];
        $rules[] = new restore_decode_rule('CURRICULUMVIEWBYID', '/mod/curriculum/view.php?id=$1', 'course_module');
        return $rules;
    }

    public static function define_restore_log_rules() {
        return [];
    }

    public static function define_restore_log_rules_for_course() {
        return [];
    }
}
