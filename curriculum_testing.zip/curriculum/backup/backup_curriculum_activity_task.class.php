<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/curriculum/backup/moodle2/backup_curriculum_stepslib.php');

class backup_curriculum_activity_task extends backup_activity_task {

    protected function define_my_steps() {
        $this->add_step(new backup_curriculum_activity_structure_step('curriculum_structure', 'curriculum.xml'));
    }

    public static function encode_content_links($content) {
        global $CFG;

        $base = preg_quote($CFG->wwwroot, '/');
        $search = "/(" . $base . "\/mod\/curriculum\/view.php\?id\=)([0-9]+)/";
        $content = preg_replace($search, '$@CURRICULUMVIEWBYID*$2@$', $content);

        return $content;
    }
}
