<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Prints an instance of mod_curriculum.
 *
 * @package     mod_curriculum
 * @copyright   2022 michaelpollak <moodle@michaelpollak.org>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__.'/../../config.php');
require_once(__DIR__.'/lib.php');

// Course module id.
$id = optional_param('id', 0, PARAM_INT);

// Activity instance id.
$c = optional_param('c', 0, PARAM_INT);

if ($id) {
    $cm = get_coursemodule_from_id('curriculum', $id, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
} else {
    $moduleinstance = $DB->get_record('curriculum', array('id' => $c), '*', MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm = get_coursemodule_from_instance('curriculum', $moduleinstance->id, $course->id, false, MUST_EXIST);
}

require_login($course, true, $cm);

$modulecontext = context_module::instance($cm->id);

$event = \mod_curriculum\event\course_module_viewed::create(array(
    'objectid' => $moduleinstance->id,
    'context' => $modulecontext
));
$event->add_record_snapshot('course', $course);
$event->add_record_snapshot('curriculum', $moduleinstance);
$event->trigger();

$PAGE->set_url('/mod/curriculum/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);

// Set the cookie before any output occured.
$url = curriculum_get_serverurl();
$token = curriculum_get_token();

echo $OUTPUT->header();
echo $OUTPUT->heading(format_string($moduleinstance->name), 2, null);

//Show intro first.
echo $OUTPUT->box(format_module_intro('curriculum', $moduleinstance, $cm->id), 'generalbox', 'intro');

$common_name = $USER->username;
if (!empty($CFG->mod_curriculum_commonname)) {
    $common_name = $CFG->mod_curriculum_commonname;
}


// Wenn wir gerade von einem Achievement Klick auf die Ampel kommen.
if(isset($_GET['achievement'])){
  $reference = $_GET['reference'];
  $postfields = [
    "user_common_name" => '["'.$common_name.'"]',
    "owner_common_name" => "$common_name",
    "referenceable_id" => "[$reference]",
    "status" => $_GET['achievement'],
    "scale" => "moodle",
  ];
  $response = sendPostRequest(curriculum_get_token(), 'achievements', $postfields);
}

// We do assume that the server is online.
$serveronline = TRUE;

// We do assume curricula are used normally.
$curricula = json_decode($moduleinstance->curriculum_elements);
$selectedareas = json_decode($moduleinstance->curriculum_elements_areas ?? '');
$selectedobjectives = json_decode($moduleinstance->curriculum_elements_objectives ?? '');

if (is_array($curricula)) {
  foreach ($curricula as &$curriculum) {

    $curr = curriculum_get_curricula($curriculum);

    // Stop if server is offline or curriculum wasn't found.
    if ($curr === FALSE OR $curr == null) {
        echo $OUTPUT->notification(get_string('serveroffline', 'mod_curriculum'), 'info');
        $serveronline = FALSE;
        break;
    }

    echo $OUTPUT->heading(format_string($curr->title), 3, null);
    echo $curr->description;

    $areas = curriculum_get_elements("v1/moodle/curricula/$curriculum/terminalObjectives?common_name=$common_name");
    if ($areas == FALSE) {
        break;
    }

    $selectedareas = array();
    $selectedareas = json_decode($moduleinstance->curriculum_elements_areas ?? '');

echo '
<style>
.fa, .far {
  padding:2px;
  font-size: large;
}
.text-green {
  color: #00a65a !important;
}
.text-orange {
  color: #fd7e14 !important;
}
.text-red {
  color: #dd4b39 !important;
}
.text-gray {
  color: #d2d6de !important;
}

.card {
  flex: 0 0 auto !important;
}

.bereich {
  width: 200px; 
  height: 200px;
  padding: 1rem;
}

.baustein {
  width: 200px; height: 200px; padding: 10px; overflow: hidden;
}
</style>
';

    // Ampel, potentiell will man das im Interface aus- und einschalten lassen können.
    if (TRUE) {
      $alleampeln = array();
      foreach ($areas as &$area) {
        if (!empty($selectedareas) AND !in_array($area->id, $selectedareas)) {
          continue;
        }
        foreach ($area->enabling_objectives as &$objective) {
          if (!empty($selectedobjectives) AND !in_array($objective->id, $selectedobjectives)) {
            continue;
          }
        $alleampeln[] = $objective->id;    
        }
      }

      // Ampeldaten der Moodle Scale sind HEX encoded, 100% = 64, 50% = 32.    
      $alleampeln = curriculum_get_data(curriculum_get_token(), 'v1/achievements?user_common_name=["'.$common_name.'"]&owner_common_name='.$common_name.'&scale=moodle&referenceable_id='.json_encode($alleampeln));

      // Neu formatieren weil ich mit dem Format so nichts anfangen kann. Array soll sein: referencable_id => status
      $neusortierteampeln = array();
      // var_dump($alleampeln); exit;
      foreach ($alleampeln as $eineampel) {
        if (!empty($eineampel->achievements)) {
          $neusortierteampeln[$eineampel->id] =  $eineampel->achievements[0]->status;
        }
      }
    }

    /*
    // Ampel thresholds sind nicht mehr 64, 32, 11 sondern Prozent, umrechnen in entsprechende Werte
    $threshold = ["64","32","11"];
    if (isset($moduleinstance->threshold)) {
      $tempdata = str_getcsv($moduleinstance->threshold, escape: '\\');
      $tempdata[0] = round($tempdata[0]/100*64);
      $tempdata[1] = round($tempdata[1]/100*64);
      $tempdata[2] = round($tempdata[2]/100*64);
      $threshold = $tempdata;
    }
    */

    // Add Bereiche as cards.
    foreach ($areas as &$area) {

        if (!empty($selectedareas) AND !in_array($area->id, $selectedareas)) {
          continue;
        }

        echo "<div class='card-deck' style='padding: .5rem;'>";
        echo "<a style='background-color:$area->color;' class='bereich card text-white' href='{$url}terminalObjectives/{$area->id}'>";
        echo $area->title;
        echo "</a>";

        // Add Bausteine as cards to the right.
        foreach ($area->enabling_objectives as &$objective) {
            if (!empty($selectedobjectives) AND !in_array($objective->id, $selectedobjectives)) {
              continue;
            }

            echo "<div class='baustein card text-dark'>";
            echo "<a class='text-dark' href='{$url}enablingObjectives/{$objective->id}'>$objective->title</a>";
            
            // Ampel.
            $ampel = array();
            if (isset($neusortierteampeln[$objective->id])) {
              $ampel = $neusortierteampeln[$objective->id];
            }

            /*
            if ($ampel>=$threshold[0]) {
              $ampelfarbe = "green";
            }
            elseif ($ampel>=$threshold[1]) {
              $ampelfarbe = "orange";
            }
            elseif ($ampel>=$threshold[2]) {
              $ampelfarbe = "red";
            } 
            else {
              $ampelfarbe = "green";
            }
            */

            switch ($ampel) {
              case '64':
                $ampelfarbe = "green";
                break;
              case '32':
                $ampelfarbe = "orange";
                break;
              case '11':
                $ampelfarbe = "red";
                break;
              default:
                $ampelfarbe = "gray"; // Wenn noch kein Eintrag in der Datenbank nehmen wir rot an.
            }
            
            // Grading URL
            $achievementurl = $_SERVER['REQUEST_URI']."&reference=$objective->id&achievement=";

            echo "<div id='ampel'>";
            $colors = array("red"=>"11", "orange"=>"32", "green"=>"64", "gray"=>"00");
			      foreach ($colors as $color => $newgrading) {
				      
              
              $icon = "far fa-circle";
              if ($color == $ampelfarbe) { $icon = "fa fa-circle"; }
              if ($color == 'gray') { $icon = "far fa-circle-check"; }
              if ($color == 'gray' AND $color == $ampelfarbe) { $icon = "fa fa-circle-check"; }

              echo "<a href='$achievementurl".$newgrading."' class='".$icon." text-".$color."'></i>";	
			      }  
            echo "</div></div>";
        }
        echo "</div>";
    }

    echo "<a href='{$url}curricula/{$curriculum}' target='_blank'>" . get_string('linkcurriculum', 'mod_curriculum', $curr->title) . "</a>";
    echo "<hr>";

  }
}

if ($serveronline === TRUE AND isset($moduleinstance->logbook_elements)) {
  $selectedlogbooks = json_decode($moduleinstance->logbook_elements);
  $alllogbooks = curriculum_get_logbooks($common_name);
  foreach ((array) $alllogbooks as &$singlelogbook) {
    if (isset($singlelogbook->id) AND in_array($singlelogbook->id, $selectedlogbooks)) {
      echo '<i class="icon fa fa-book"></i>';
      echo "<a href='{$url}logbooks/{$singlelogbook->id}' target='_blank'>" . get_string('linklogbook', 'mod_curriculum', $singlelogbook->title) . "</a><br>";
    }
  }
}

if ($serveronline === TRUE AND isset($moduleinstance->kanban_elements)) {
  $selectedkanbans = json_decode($moduleinstance->kanban_elements);
  $allkanbans = curriculum_get_kanbans($common_name);
  foreach ((array) $allkanbans as &$singlekanban) {
    if (isset($singlekanban->id) AND in_array($singlekanban->id, $selectedkanbans)) {
      echo '<i class="icon fa fa-columns"></i>';
      echo "<a href='{$url}kanbans/{$singlekanban->id}' target='_blank'>" . get_string('linkkanban', 'mod_curriculum', $singlekanban->title) . "</a><br>";
    }
  }
}

echo $OUTPUT->footer();
