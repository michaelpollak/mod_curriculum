<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Prints an instance of mod_curriculum.
 *
 * @package     mod_curriculum
 * @copyright   2026 michaelpollak <moodle@michaelpollak.org>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__.'/../../config.php');
require_once(__DIR__.'/lib.php');

// Course module id.
$id = optional_param('id', 0, PARAM_INT);

// Activity instance id.
$c = optional_param('c', 0, PARAM_INT);

if ($id) {
    $cm = get_coursemodule_from_id('curriculum', $id, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
} else {
    $moduleinstance = $DB->get_record('curriculum', array('id' => $c), '*', MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm = get_coursemodule_from_instance('curriculum', $moduleinstance->id, $course->id, false, MUST_EXIST);
}

require_login($course, true, $cm);

$modulecontext = context_module::instance($cm->id);

$event = \mod_curriculum\event\course_module_viewed::create(array(
    'objectid' => $moduleinstance->id,
    'context' => $modulecontext
));
$event->add_record_snapshot('course', $course);
$event->add_record_snapshot('curriculum', $moduleinstance);
$event->trigger();

$PAGE->set_url('/mod/curriculum/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);

// Set the cookie before any output occured.
$url = curriculum_get_serverurl();
$token = curriculum_get_token();

echo $OUTPUT->header();
echo $OUTPUT->heading(format_string($moduleinstance->name), 2, null);

//Show intro first.
echo $OUTPUT->box(format_module_intro('curriculum', $moduleinstance, $cm->id), 'generalbox', 'intro');

$common_name = $USER->username;
if (!empty($CFG->mod_curriculum_commonname)) {
    $common_name = $CFG->mod_curriculum_commonname;
}


// Wenn wir gerade von einem Achievement Klick auf die Ampel kommen.
if(isset($_GET['achievement'])){
  $reference = $_GET['reference'];
  $postfields = [
    "user_common_name" => '["'.$common_name.'"]',
    "owner_common_name" => "$common_name",
    "referenceable_id" => "[$reference]",
    "status" => $_GET['achievement']
  ];
  $response = sendPostRequest(curriculum_get_token(), 'achievements', $postfields);
}

// We do assume that the server is online.
$serveronline = TRUE;

// We do assume curricula are used normally.
$curriculum = $moduleinstance->curriculum_elements;
$selectedareas = json_decode($moduleinstance->curriculum_elements_areas ?? '');
$selectedobjectives = json_decode($moduleinstance->curriculum_elements_objectives ?? '');

if (isset($curriculum) AND $curriculum == "0") {
    echo $OUTPUT->notification('Es wurde noch kein Curriculum eingerichtet. Wenden Sie sich an Ihre Lehrperson.', 'info'); // TODO: Translate.
}

if (isset($curriculum) AND $curriculum != "0") {

    $curr = curriculum_get_curricula($curriculum);

    // Stop if server is offline or curriculum wasn't found.
    if ($curr === FALSE OR $curr == null) {
        echo $OUTPUT->notification(get_string('serveroffline', 'mod_curriculum'), 'info');
        $serveronline = FALSE;
    }

    if ($serveronline) {
      echo $OUTPUT->heading(format_string($curr->title), 3, null);
      echo $curr->description;
    }

    $areas = curriculum_get_elements("v1/moodle/curricula/$curriculum/terminalObjectives?common_name=$common_name");
    $selectedareas = array();
    $selectedareas = json_decode($moduleinstance->curriculum_elements_areas ?? '');

    // Ampel, potentiell will man das im Interface aus- und einschalten lassen können.
    $ampelzeigen = true;
    $context = context_course::instance($COURSE->id);
    if (has_capability('moodle/course:update', $context, $USER)) {
      // Wir sind Lehrer und wollen die Ampel nicht sehen.
      $ampelzeigen = false;
    }


    if ($ampelzeigen) {
      $alleampeln = array();
      foreach ($areas as &$area) {
        if (!empty($selectedareas) AND !in_array($area->id, $selectedareas)) {
          continue;
        }
        foreach ($area->enabling_objectives as &$objective) {
          //if (!empty($selectedobjectives) AND !in_array($objective->id, $selectedobjectives)) {
          //  continue;
          //}
          // Wir zeigen alle an wenn keines gewählt ist.
          $alleampeln[] = $objective->id;    
        }
      }

      // Ampeldaten sind Chars, XX, Selbst, Fremd 0 grau, 1 grün, 2 gelb, 3 rot
      $alleampeln = curriculum_get_data(curriculum_get_token(), 'v1/achievements?user_common_name=["'.$common_name.'"]&owner_common_name='.$common_name.'&scale=moodle&referenceable_id='.json_encode($alleampeln));

      // Neu formatieren, array soll sein: referencable_id => status.
      $neusortierteampeln = array();
      foreach ($alleampeln as $eineampel) {
        if (!empty($eineampel->achievements)) {
          $neusortierteampeln[$eineampel->id] =  $eineampel->achievements[0]->status;
        }
      }
    }

    // Add Bereiche as cards.
    foreach ($areas as &$area) {

        if (!empty($selectedareas) AND !in_array($area->id, $selectedareas)) {
          continue;
        }

        echo "<div class='card-deck' style='padding: .5rem;'>";
        echo "<a style='background-color:$area->color;' class='bereich card text-white' href='{$url}terminalObjectives/{$area->id}'>";
        echo $area->title;
        echo "</a>";


        // Prüfen ob wir für diesen Bereich einen Baustein haben, wenn nicht wollen wir ALLE Bausteine anzeigen.
        $zeigealle = true;
        foreach ($area->enabling_objectives as &$objective) {
          if(empty($selectedobjectives)) {
            break;
          }
          if (in_array($objective->id, $selectedobjectives)) {
              $zeigealle = false;
              break; // Wir haben eines gefunden, das reicht.
            }
        }

        // Add Bausteine as cards to the right.
        foreach ($area->enabling_objectives as &$objective) {
            if (!$zeigealle AND !empty($selectedobjectives) AND !in_array($objective->id, $selectedobjectives)) {
              continue;
            }

            echo "<div class='baustein card text-dark'>";
            echo "<a class='text-dark' href='{$url}enablingObjectives/{$objective->id}'>$objective->title</a>";
            
            // Ampel.
            if ($ampelzeigen) {
            $ampel = $ampelfarbe = $ampelhakerl= '';
          
            if (isset($neusortierteampeln[$objective->id])) {
              $ampel = $neusortierteampeln[$objective->id];
              $ampelfarbe = substr($ampel, 0, 1);
              $ampelhakerl = substr($ampel, 1, 2); // Fremdeinschätzung, 1,2,3,0.
            }

            switch ($ampelfarbe) {
              case '1':
                $kreisfarbe = "green";
                break;
              case '2':
                $kreisfarbe = "orange";
                break;
              case '3':
                $kreisfarbe = "red";
                break;
              default:
                $kreisfarbe = "gray"; // Wenn noch kein Eintrag in der Datenbank nehmen wir grau an.
            }

            // Grading URL
            $achievementurl = $_SERVER['REQUEST_URI']."&reference=$objective->id&achievement=";

            echo "<div class='ampel'>";
            $colors = array("green"=>"1", "orange"=>"2", "red"=>"3", "gray"=>"0");
			      foreach ($colors as $color => $newgrading) {
              $icon = "far fa-circle";
              if ($color == $kreisfarbe) { $icon = "fa fa-circle"; } // Selbsteinschätzung.
              if ($newgrading == $ampelhakerl) { $icon = "far fa-circle-check"; } // Fremdeinschätzung.
              if ($color == $kreisfarbe AND $newgrading == $ampelhakerl) { $icon = "fa fa-circle-check"; } // Deckungsgleich.
              // 0x, 1x, 2x, 3x: encoding mit x als whitecard.
              echo "<a href='$achievementurl".$newgrading."x' class='".$icon." text-".$color."'></i>";
			      }  
            echo "</div>";
            } // Ende von if ($ampelzeigen).

            echo "</div>";
        }
        echo "</div>";
    }
    // Woher kriegen wir die Gruppe?
    // echo "<a href='{$url}course/{$curriculum}' target='_blank'>" . get_string('linkcurriculum', 'mod_curriculum', $curr->title) . "</a>";
    echo "<hr>";

}

if ($serveronline === TRUE AND isset($moduleinstance->logbook_elements)) {
  $selectedlogbooks = json_decode($moduleinstance->logbook_elements);
  $alllogbooks = curriculum_get_logbooks($common_name);
  foreach ((array) $alllogbooks as &$singlelogbook) {
    if (isset($singlelogbook->id) AND in_array($singlelogbook->id, $selectedlogbooks)) {
      echo '<i class="icon fa fa-book"></i>';
      echo "<a href='{$url}logbooks/{$singlelogbook->id}' target='_blank'>" . get_string('linklogbook', 'mod_curriculum', $singlelogbook->title) . "</a><br>";
    }
  }
}

if ($serveronline === TRUE AND isset($moduleinstance->kanban_elements)) {
  $selectedkanbans = json_decode($moduleinstance->kanban_elements);
  $allkanbans = curriculum_get_kanbans($common_name);
  foreach ((array) $allkanbans as &$singlekanban) {
    if (isset($singlekanban->id) AND in_array($singlekanban->id, $selectedkanbans)) {
      echo '<i class="icon fa fa-columns"></i>';
      echo "<a href='{$url}kanbans/{$singlekanban->id}' target='_blank'>" . get_string('linkkanban', 'mod_curriculum', $singlekanban->title) . "</a><br>";
    }
  }
}

echo $OUTPUT->footer();
