<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.
/**
 * Send achievement back to server.
 *
 * @param object $moduleinstance An object from the form.
 * @param mod_curriculum_mod_form $mform The form.
 * @return int The id of the newly inserted record.
 */
if(isset($_GET['test'])){
$achievementurl = "https://curriculum-dev.schulcampus-rlp.de/apiv1/achievements?user_common_name=2d3fc3d1-4b84-4faa-a518-9f0a10ced88e&owner_common_name=2d3fc3d1-4b84-4faa-a518-9f0a10ced88e&referenceable_id=435&scale=moodle&status=64";
$message = urlencode("After clicking the button, the form will submit to home.php. When, the page home.php loads, the previous page index.php is redirected. ");
header("Location:".$_GET['prev']."?message=".$message);
die;
}