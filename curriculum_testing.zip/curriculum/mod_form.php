<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * The main mod_curriculum configuration form.
 *
 * @package     mod_curriculum
 * @copyright   2022 michaelpollak <moodle@michaelpollak.org>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/course/moodleform_mod.php');

/**
 * Module instance settings form.
 *
 * @package     mod_curriculum
 * @copyright   2025 michaelpollak <moodle@michaelpollak.org>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_curriculum_mod_form extends moodleform_mod {

    /**
     * Defines forms elements
     */
    public function definition() {
        global $CFG, $USER, $DB;

        $common_name = $USER->username;
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }

        $mform = $this->_form;

        // Adding the "general" fieldset, where all the common settings are shown.
        $mform->addElement('header', 'general', get_string('general', 'form'));

        // Adding the standard "name" field.
        $mform->addElement('text', 'name', get_string('curriculumname', 'mod_curriculum'), array('size' => '64'));

        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('name', PARAM_TEXT);
        } else {
            $mform->setType('name', PARAM_CLEANHTML);
        }

        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');
        $mform->addHelpButton('name', 'curriculumname', 'mod_curriculum');

        // Adding the standard "intro" and "introformat" fields.
        if ($CFG->branch >= 29) {
            $this->standard_intro_elements();
        } else {
            $this->add_intro_editor();
        }

        // Add curricula.
        $mform->addElement('header', 'curricula', get_string('curricula', 'mod_curriculum'));
        $mform->setExpanded('curricula');

        // Show autoselect of all curriculum elements.
        $areanames = array();
        $token = curriculum_get_token();
        $allcurricula = curriculum_get_all_curricula($common_name);

        // If false stop here, show error and help.
        if ($allcurricula === FALSE) {
            $mform->addElement('html', '<div class="alert alert-danger" role="alert">' . get_string('serveroffline', 'mod_curriculum') . '</div>');
        }

        if (is_array($allcurricula)) {
            foreach ($allcurricula as &$curriculum) {
                $currnames[$curriculum->id] = $curriculum->title;
            }

            $options = array(
                'multiple' => true,
                'placeholder' => get_string('currselect', 'mod_curriculum'),
            );
            $mform->addElement('autocomplete', 'curriculum_elements', get_string('currviews', 'mod_curriculum'), $currnames, $options);
        }

        // If curricula is selected and only one visible show bereiche to select.
        $mform->addElement('static', 'description', "", get_string('exactlyone', 'mod_curriculum'));

        // If we see exactly one curriculum_elements we look for areas and objectives.
        $current = $this->get_current();
        if (isset($current->curriculum_elements)) {
          $current_elements = json_decode($current->curriculum_elements);
        }

        if (isset($current_elements) AND count($current_elements) == 1) {
          $areas = curriculum_get_elements("v1/moodle/curricula/" . $current_elements['0'] . "/terminalObjectives?common_name=$common_name");
          $areanames = array();
          foreach ($areas as &$area) {
            $areanames[$area->id] = $area->title;
          }
          $mform->addElement('autocomplete', 'curriculum_elements_areas', get_string('currviews_areas', 'mod_curriculum'), $areanames, $options);
          $mform->setAdvanced('curriculum_elements_areas', false);

          // TODO: Show only objectives that can be reached with the areas.
          $objectives = curriculum_get_elements("v1/moodle/curricula/" . $current_elements['0'] . "/enablingObjectives?common_name=$common_name");
          $objectivenames = array();
          foreach ($objectives as &$objective) {
            $objectivenames[$objective->id] = $objective->title;
          }
          $mform->addElement('autocomplete', 'curriculum_elements_objectives', get_string('currviews_objectives', 'mod_curriculum'), $objectivenames, $options);
          $mform->setAdvanced('curriculum_elements_objectives', false);
          


        // TESTING Add Verknüpfungen.
        // Verknüpfung von Moodle-Bewertungselementen mit Kompetenzraster-Bausteinen
        // Idee, wenn man hier ein Curriculum anlegt und ein spezielles Curriculum sucht kann man danach auswählen welcher Baustein mit welcher Aktivität verknüpft werden soll.
 
        $mform->addElement('header', 'links', get_string('links', 'mod_curriculum'));
		
		//	Alle activities
		$courseid = $this->current->course;
		$modinfo = get_fast_modinfo($courseid);
		$activities = [];
		$activities[0] = "Keine";
		
		foreach ($modinfo->get_cms() as $cm) {
		    if (!$cm->uservisible) {
		        continue;
		    }
		    $activities[$cm->id] = $cm->name . ' (' . $cm->modname . ')';
		}
    $objectivenames[0] = "Keine";


// Testing repeated imput fields to get additional link fields.    
$repeatarray = [
    $mform->createElement('autocomplete', 'curriculum_triggeractivity', get_string('triggeractivity', 'mod_curriculum'), $activities),
    $mform->createElement('autocomplete', 'curriculum_triggerobjectives', get_string('triggerobjectives', 'mod_curriculum'), $objectivenames, array('multiple' => true)),
    $mform->createElement('html', '<hr>'),
];

if ($this->_instance){
  $numberoftriggers = $DB->get_record('curriculum', array('id' => $this->_instance), 'curriculum_triggeractivity', MUST_EXIST);
    $repeatno = count(json_decode($numberoftriggers->curriculum_triggeractivity));
} else {
    $repeatno = 1;
}

$repeateloptions = [
    'curriculum_triggeractivity' => [
        'default' => 0,
        'multiple' => false,
        'setAdvanced' => false,
        'type' => PARAM_INT,
        'helpbutton' => [
          'triggeractivity',
          'curriculum',
        ]
    ],
    'curriculum_triggerobjectives' => [
        'default' => 0,
        'multiple' => true,
        'setAdvanced' => false,
        'type' => PARAM_INT,
        'helpbutton' => [
          'triggeractivity',
          'curriculum',
        ]
    ],
];


$this->repeat_elements(
    $repeatarray,
    $repeatno,
    $repeateloptions,
    'option_repeats',
    'option_add_fields',
    1,
    null,
    true,
    'delete',
);



/*
		$linkoptions = array(
			'multiple' => false
    );
            
		$mform->addElement('autocomplete', 'curriculum_triggeractivity', get_string('triggeractivity', 'mod_curriculum'), $activities, $linkoptions);
		$mform->setType('curriculum_triggeractivity', PARAM_INT);
		$mform->setAdvanced('curriculum_triggeractivity', false);
		$mform->addHelpButton('curriculum_triggeractivity', 'triggeractivity', 'mod_curriculum');
		$mform->setDefault('curriculum_triggeractivity', 0);
		
    $linkoptions = array(
			'multiple' => true
    );
		$objectivenames[0] = "Keine";
		$mform->addElement('autocomplete', 'curriculum_triggerobjectives', get_string('triggerobjectives', 'mod_curriculum'), $objectivenames, $linkoptions);
		$mform->setType('curriculum_triggerobjectives', PARAM_INT);
        $mform->setAdvanced('curriculum_triggerobjectives', false);
        $mform->setDefault('curriculum_triggerobjectives', 0);
        
*/    
        

        }

// TODO: Das Plugin soll in drei Plugins aufgeteilt werden.
/*
        // Add logbook.
        $mform->addElement('header', 'logbook', get_string('logbook', 'mod_curriculum'));

        // Show autoselect of all curriculum elements.
        $areanames = array();
        $alllogbooks = curriculum_get_logbooks($common_name);

        // If false stop here, show error and help.
        if ($alllogbooks === FALSE) {
          $mform->addElement('html', '<div class="alert alert-danger" role="alert">' . get_string('serveroffline', 'mod_curriculum') . '</div>');
        }

        if (is_array($alllogbooks)) {
          foreach ($alllogbooks as &$logbook) {
            $areanames[$logbook->id] = $logbook->title;
          }

          $options = array(
            'multiple' => true,
            'placeholder' => get_string('currselect', 'mod_curriculum'),
          );
          $mform->addElement('autocomplete', 'logbook_elements', get_string('logviews', 'mod_curriculum'), $areanames, $options);
        }

        // Add kanban.
        $mform->addElement('header', 'kanban', get_string('kanban', 'mod_curriculum'));

        // Show autoselect of all curriculum elements.
        $areanames = array();
        $allkanbans = curriculum_get_kanbans($common_name);

        // If false stop here, show error and help.
        if ($allkanbans === FALSE) {
          $mform->addElement('html', '<div class="alert alert-danger" role="alert">' . get_string('serveroffline', 'mod_curriculum') . '</div>');
        }

        if (is_array($allkanbans)) {
          foreach ($allkanbans as &$kanban) {
            $areanames[$kanban->id] = $kanban->title;
          }

          $options = array(
            'multiple' => true,
            'placeholder' => get_string('currselect', 'mod_curriculum'),
          );
          $mform->addElement('autocomplete', 'kanban_elements', get_string('kanviews', 'mod_curriculum'), $areanames, $options);
        }
        
*/


        // Add standard elements.
        $this->standard_coursemodule_elements();

        // Add standard buttons.
        $this->add_action_buttons();
    }

    /**
     * Modify data for display in mod_form.
     *
     * @param stdClass $data the form data to be modified.
     */
    function data_preprocessing(&$default_values){
        if (isset($default_values['curriculum_elements'])) {
            $default_values['curriculum_elements'] = json_decode($default_values['curriculum_elements']);
        }
        if (isset($default_values['curriculum_elements_areas'])) {
            $default_values['curriculum_elements_areas'] = json_decode($default_values['curriculum_elements_areas']);
        }
        if (isset($default_values['curriculum_elements_objectives'])) {
            $default_values['curriculum_elements_objectives'] = json_decode($default_values['curriculum_elements_objectives']);
        }
        // Testing triggeractivities.
        if (isset($default_values['curriculum_triggeractivity'])) {

          $triggeract = json_decode($default_values['curriculum_triggeractivity']);
          $triggerobj = json_decode($default_values['curriculum_triggerobjectives']);
          
          foreach ($triggeract as $key => $value){
            $default_values['curriculum_triggeractivity['.$key.']'] = $value;
            $default_values['curriculum_triggerobjectives['.$key.']'] = $triggerobj[$key];
          }

        }
    
/*
        if (isset($default_values['curriculum_triggeractivity'])) {
            $default_values['curriculum_triggeractivity'] = json_decode($default_values['curriculum_triggeractivity']);
        }
        if (isset($default_values['curriculum_triggerobjectives'])) {
            $default_values['curriculum_triggerobjectives'] = json_decode($default_values['curriculum_triggerobjectives']);
        }
*/





        if (isset($default_values['logbook_elements'])) {
            $default_values['logbook_elements'] = json_decode($default_values['logbook_elements']);
        }

        if (isset($default_values['kanban_elements'])) {
            $default_values['kanban_elements'] = json_decode($default_values['kanban_elements']);
        }
    }

    /**
     * Modify data before storing in db.
     *
     * @param stdClass $data the form data to be modified.
     */
    public function data_postprocessing($data) {
        parent::data_postprocessing($data);

        if (isset($data->curriculum_elements)) {
          $data->curriculum_elements = json_encode($data->curriculum_elements);
        }

        if (isset($data->curriculum_elements_areas)) {
          $data->curriculum_elements_areas = json_encode($data->curriculum_elements_areas);
        }

        if (isset($data->curriculum_elements_objectives)) {
          $data->curriculum_elements_objectives = json_encode($data->curriculum_elements_objectives);
        }
        
        if (isset($data->logbook_elements)) {
          $data->logbook_elements = json_encode($data->logbook_elements);
        }

        if (isset($data->kanban_elements)) {
          $data->kanban_elements = json_encode($data->kanban_elements);
        }
        
        if (isset($data->curriculum_triggeractivity)) {
          $data->curriculum_triggeractivity = json_encode($data->curriculum_triggeractivity);  		  
        }
        if (isset($data->curriculum_triggerobjectives)) {
          $data->curriculum_triggerobjectives = json_encode($data->curriculum_triggerobjectives);
          // Ausserdem in globaler Triggerdatenbank speichern!
        }
        
        // Prüfe ob der Link schon besteht, wenn nicht passe das globale Triggerarray entsprechend an.
        if (isset($data->curriculum_triggeractivity) AND isset($data->curriculum_triggerobjectives)) {
			    global $DB;

            $linkdata = new stdClass();
            $linkdata->course = $data->coursemodule; // coursemoduleid
			      $linkdata->activityid = intval(str_replace("\"", '', $data->curriculum_triggeractivity));
			      $linkdata->bausteinid = intval(str_replace("\"", '', $data->curriculum_triggerobjectives)); // referenceid

          // Prüfen ob von dieser cmid schon ein Eintrag existiert.
          $links = $DB->get_record('curriculum_links', array('course' => $data->coursemodule));
          if ($links) {
            // Der Eintrag muss aktualisiert werden.
            $linkdata->id = $links->id;
            $DB->update_record('curriculum_links', $linkdata);
          } 
          if (!$links) {
            // Füge neuen Eintrag zur Tracked Linkliste ein.
			      $DB->insert_record('curriculum_links', $linkdata);
          }
        }
          		  

		}

    
}
