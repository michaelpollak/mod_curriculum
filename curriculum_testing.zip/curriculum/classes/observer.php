<?php
class mod_curriculum_observer

{
    // Bei jeder Beurteilung übergeben wir die Infos an Curriculum.
	public static function graded(\mod_assign\event\submission_graded $event)
    {
        $event_data = $event->get_data();

        $courseid = $event_data["courseid"];
        $contextinstance = $event_data["contextinstanceid"];
        $userid = $event_data["userid"];
        
        // Auslesen der Grading Daten.
        $gradetabelle = $event->get_record_snapshot("assign_grades", $event_data["objectid"]);
        $grade = $gradetabelle->grade; // float.

        // Übergabe an Curriculum vorbereiten.
        $achievements = array();
        $achievements["scale"] = "percentage";
        $achievements["status"] = number_format($grade,0,'.',''); // Konvertieren von Float zu Int.
        $achievements["owner_id"] = $event_data["userid"];
        
        require_once __DIR__ . '/../lib.php';
        $response = curriculum_get_data(curriculum_get_token(), "v1/moodle/curricula?scale=percentage&status=".number_format($grade,0,'.','')."&owner_id=".$event_data["userid"]);

    }	
    
    // Bei jeder Einschreibung schalten wir Pinnwände in Curriculum frei.
	public static function enrolled(\core\event\user_enrolment_created $event)
    {
		global $DB;
        $event_data = $event->get_data();

        // Auslesen welche Kanbans in diesem Kurs genutzt werden.
        $cm = get_coursemodule_from_id('curriculum', $event_data["courseid"], 0, false, MUST_EXIST);
		$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
		$moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
		$kanbans = $moduleinstance->kanban_elements;
		
		// TODO: Nur wenn Kanbans vorhanden weitermachen.
		require_once __DIR__ . '/../lib.php';
		$response = curriculum_get_data(curriculum_get_token(), "v1/moodle/users/enrol?users=".$event_data["userid"]."&kanbans=".$kanbans);
    }
    	
    // Bei jeder Ausschreibung entfernen wir Berechtigungen in Curriculum.
	public static function disroled(\core\event\user_enrolment_deleted $event)
    {
		global $DB;
        $event_data = $event->get_data();

        // Auslesen welche Kanbans in diesem Kurs genutzt werden.
        $cm = get_coursemodule_from_id('curriculum', $event_data["courseid"], 0, false, MUST_EXIST);
		$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
		$moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
		$kanbans = $moduleinstance->kanban_elements;
		
		// TODO: Nur wenn Kanbans vorhanden weitermachen.
		require_once __DIR__ . '/../lib.php';
		$response = curriculum_get_data(curriculum_get_token(), "v1/moodle/users/expel?users=".$event_data["userid"]."&kanbans=".$kanbans);
    }
    
    // Bei jedem Aktivitätsabschluss prüfen ob wir das tracken.
    public static function completed(\core\event\course_module_completion_updated $event) {
        global $DB;
        global $CFG;
        
        // Wenn als nicht erledigt markiert ignorieren.
        if ($event->other["completionstate"] != 1) {
			return;
		}
        
        $cmid = $event->contextinstanceid;
        
        // Tracked: kursID, acticityID, referenceID, curriculum_triggerobjectives
        $temptracked = $DB->get_records('curriculum_links', array('activityid' => $cmid));
        if (!$temptracked) {
            return;
        }

        $common_name = $USER->username;
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }
        require_once __DIR__ . '/../lib.php';
        foreach($temptracked as $singletrack) {
            $postfields = [
                "user_common_name" => '["'.$common_name.'"]',
                "owner_common_name" => "$common_name",
                "referenceable_id" => "[$singletrack->bausteinid]",
                "status" => "64",
                "scale" => "moodle",
            ]; // "status" => number_format($grade,0,'.',''), "scale" => "percentage",
        
            $response = sendPostRequest(curriculum_get_token(), 'achievements', $postfields);
        }
        
        // Auslesen welche Aktivitäten getracked werden, wenn nicht in dieser Liste stoppen.

        
         



    }
}
