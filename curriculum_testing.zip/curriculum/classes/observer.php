<?php
class mod_curriculum_observer

{
    // Bei jeder Beurteilung übergeben wir die Infos an Curriculum.
	public static function graded(\mod_assign\event\submission_graded $event)
    {
        $event_data = $event->get_data();

        $courseid = $event_data["courseid"];
        $contextinstance = $event_data["contextinstanceid"];
        $userid = $event_data["userid"];
        
        // Auslesen der Grading Daten.
        $gradetabelle = $event->get_record_snapshot("assign_grades", $event_data["objectid"]);
        $grade = $gradetabelle->grade; // float.

        // Übergabe an Curriculum vorbereiten.
        $achievements = array();
        $achievements["scale"] = "percentage";
        $achievements["status"] = number_format($grade,0,'.',''); // Konvertieren von Float zu Int.
        $achievements["owner_id"] = $event_data["userid"];
        
        require_once __DIR__ . '/../lib.php';
        $response = curriculum_get_data(curriculum_get_token(), "v1/moodle/curricula?scale=percentage&status=".number_format($grade,0,'.','')."&owner_id=".$event_data["userid"]);

    }	
    
    // Bei jeder Einschreibung schalten wir Curricula in Curriculum frei.
	public static function enrolled(\core\event\user_enrolment_created $event)
    {



		global $DB;
        $event_data = $event->get_data();
        
        // Auslesen welche Curricula in diesem Kurs genutzt werden.
        $cm = get_coursemodule_from_id('curriculum', $event_data["courseid"], 0, false, MUST_EXIST);
		$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
		$moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
		$kanbans = $moduleinstance->kanban_elements;
        $curricula = $moduleinstance->curriculum_elements;

		require_once __DIR__ . '/../lib.php';

        // Nicht userid sondern username als common name senden.
        $common_name = $DB->get_field('user', 'username', array( 'id' => $event_data["relateduserid"]) );
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }

        $postfields = [
            "users" => "[\"". $common_name ."\"]",
            "kanbans" => $kanbans,
            "curricula" => $curricula,
            "groups" => "[\"".$course->shortname."\"]"
        ];
        $response = sendPostRequest(curriculum_get_token(), 'moodle/users/enrol', $postfields);
        

    }
    	
    // Bei jeder Ausschreibung entfernen wir Berechtigungen in Curriculum.
	public static function disroled(\core\event\user_enrolment_deleted $event)
    {
		global $DB;
        $event_data = $event->get_data();

        // Auslesen welche Curricula in diesem Kurs genutzt werden.
        $cm = get_coursemodule_from_id('curriculum', $event_data["courseid"], 0, false, MUST_EXIST);
		$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
		$moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
		$kanbans = $moduleinstance->kanban_elements;
        $curricula = $moduleinstance->curriculum_elements;

		require_once __DIR__ . '/../lib.php';

        // Nicht userid sondern username als common name senden.
        $common_name = $DB->get_field('user', 'username', array( 'id' => $event_data["relateduserid"]) );
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }

        $postfields = [
            "users" => "[\"". $common_name ."\"]",
            "kanbans" => $kanbans,
            "curricula" => $curricula,
            "groups" => "[\"".$course->shortname."\"]"
        ];
        $response = sendPostRequest(curriculum_get_token(), 'moodle/users/expel', $postfields);

    }
    
    // Bei jedem Aktivitätsabschluss prüfen ob wir das tracken.
    public static function completed(\core\event\course_module_completion_updated $event) {
        global $DB;
        global $CFG;
        
        // Wenn als nicht erledigt markiert ignorieren.
        if ($event->other["completionstate"] != 1) {
			return;
		}
        
        $event_data = $event->get_data();
        $cmid = $event->contextinstanceid;

        $temptracked = $DB->get_records_menu('curriculum_links',  array('course' => $event_data["courseid"]), '', 'activityid, bausteinid');
        if (!$temptracked) {
            return;
        }

        // Lese alle Temptracked in ein array
        $melden = array();

        foreach ($temptracked as $activityids => $bausteinids) {
            $checkout = array();
            $checkout = json_decode($activityids);
            $relevantebausteine = json_decode($bausteinids);
            foreach($checkout as $key => $activity) {
                if ($activity == $cmid) {
                    foreach($relevantebausteine[$key] as $a => $baustein)
                    $melden[] = $baustein;
                }
            }
        }
       
        $common_name = $USER->username;
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }
        require_once __DIR__ . '/../lib.php';

        // Achtung, bausteinid ist json encode [["123","456"]]
            $bausteine = json_encode($melden);
            $postfields = [
                "user_common_name" => '["'.$common_name.'"]',
                "owner_common_name" => "$common_name",
                "referenceable_id" => "[$bausteine]",
                "status" => "64",
                "scale" => "moodle",
            ]; // "status" => number_format($grade,0,'.',''), "scale" => "percentage",
        
            $response = sendPostRequest(curriculum_get_token(), 'achievements', $postfields);
        }
        

        
         



    
}
