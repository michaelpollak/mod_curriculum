<?php
namespace mod_curriculum;

defined('MOODLE_INTERNAL') || die();

class observer {

    // Bei jeder Beurteilung übergeben wir die Infos an Curriculum.
	public static function graded(\mod_assign\event\submission_graded $event)
    {
        global $DB;
        global $CFG;
        global $USER;

   
        $event_data = $event->get_data();

        $courseid = $event_data["courseid"];

        // Schauen ob das überhaupt getracked wird. Gibt es ein Curriculum im Kurs?
        $cms = get_coursemodules_in_course('curriculum', $courseid);
        if (empty($cms)) {
            return;
        }

        $common_name = $USER->username;
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }

        // Auslesen der Grading Daten.
        $gradetabelle = $event->get_record_snapshot("assign_grades", $event_data["objectid"]);
        $grade = intval($gradetabelle->grade); // ursprünglich float.

        if ($grade === null) {
            return;
        }

        // Kommt die Aktivität in einer Kompetenzverknüpfung vor?
        $currentactivity = $event->contextinstanceid; // cmid der gegradeten Aktivität, schauen ob es in der liste der triggeractivities steht. daztugehörige triggerobjective rausfiltern.

        foreach ($cms as $cm) {
            $moduleinstance = $DB->get_record( 'curriculum', ['id' => $cm->instance], '*', MUST_EXIST );
            $triggeractivities = json_decode($moduleinstance->curriculum_triggeractivity, true);
            
            $index = array_search($currentactivity, $triggeractivities, true);
            // Wir wissen, dass es eine Verknüpfung gibt und welche objectives verknüpft sind.
            
            if ($index !== false) {

                $linked = $moduleinstance->curriculum_triggerobjectives;
                $linked = json_decode($linked);

                $melden = array();

                foreach ($triggeractivities as $key => $act) {
                    if ($act == $currentactivity) {
                        foreach ($linked[$key] as $value) {
                            if ($value !== "0") {
                                $melden[] = $value;
                            }
                        }
                    }
                }

                // Wir haben eine Array mit allen Objectives die in diesem Kurs mit diesem Trigger verbunden sind.
                // Wir senden das gesammelt pro Instanz an Curriculum weil tresholds eingehalten werden müssen.
                // Wenn Grade den threshold erreicht hat dann schicke grün, Ampeldaten sind Chars, XX, Selbst, Fremd 0 grau, 1 grün, 2 gelb, 3 rot
                $bewert = "XX";
                if ($grade >= $moduleinstance->threshold) {
                    $bewert = "X1";
                } else if ($grade >= $moduleinstance->thresholdyellow) {
                    $bewert = "X2";
                } else {
                    $bewert = "X3";
                }

                require_once __DIR__ . '/../lib.php';

                $bausteine = json_encode($melden);
                $postfields = [
                    "user_common_name" => '["'.$common_name.'"]',
                    "owner_common_name" => "$common_name",
                    "referenceable_id" => $bausteine,
                    "status" => $bewert
                ];

                $response = sendPostRequest(curriculum_get_token(), 'achievements', $postfields);        
            }
        }
    }	
    
    // Bei jeder Einschreibung schalten wir Curricula in Curriculum frei.
	public static function enrolled(\core\event\user_enrolment_created $event)
    {

		global $DB;
        global $SITE;
        $event_data = $event->get_data();
        
        // Auslesen welche Curricula in diesem Kurs genutzt werden.
        $cms = get_coursemodules_in_course('curriculum', $event_data["courseid"]);
        if (empty($cms)) {
            return; // Keines, also fertig.
        }
        $cm = reset($cms);
		$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
		$moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
        $curricula = $moduleinstance->curriculum_elements;

		require_once __DIR__ . '/../lib.php';

        // Suche alle eingetragenen User, egal welche Rolle.
        $courseid = $event->courseid;
        $enrolled = get_enrolled_users( \context_course::instance($courseid), '', 0, 'u.id, u.username' );

        $common_names = array();
        foreach ($enrolled as $user) {
            $common_names[] = $user->username;
        }

        $postfields = [
            "users" => json_encode($common_names),
            "curricula" => json_encode([$curricula]),
            "groups" => json_encode([$course->shortname]),
            "organization" => "DE-RP-" . $SITE->shortname
        ];
        $response = sendPostRequest(curriculum_get_token(), 'moodle/users/enrol', $postfields);

    }
    	
    // Bei jeder Ausschreibung entfernen wir Berechtigungen in Curriculum.
	public static function disroled(\core\event\user_enrolment_deleted $event)
    {
		global $DB;
        global $SITE;
        $event_data = $event->get_data();

        // Wir triggern nicht wenn der ganze Kurs gelöscht wird.
        $cm = get_coursemodule_from_id('curriculum', $event->courseid, 0, false, IGNORE_MISSING);
        
        if (!$cm) {
            return;
        }

        // Auslesen welche Curricula in diesem Kurs genutzt werden.
		$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
		$moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
		$kanbans = $moduleinstance->kanban_elements;
        $curricula = $moduleinstance->curriculum_elements;

		require_once __DIR__ . '/../lib.php';

        // Nicht userid sondern username als common name senden.
        $common_name = $DB->get_field('user', 'username', array( 'id' => $event_data["relateduserid"]) );
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }

        $postfields = [
            "users" => "[\"". $common_name ."\"]",
            "curricula" => "[\"". $curricula ."\"]",
            "groups" => "[\"".$course->shortname."\"]",
            "organization" => "DE-RP-" . $SITE->shortname
        ];
        $response = sendPostRequest(curriculum_get_token(), 'moodle/users/expel', $postfields);

    }
    
    // Bei jedem Aktivitätsabschluss prüfen ob wir das tracken.
    public static function completed(\core\event\course_module_completion_updated $event) {

        /*
        Implementierung zum Testen, nicht im Pflichtenheft.

        global $DB;
        global $CFG;
        global $USER;

        // Wenn als nicht erledigt markiert ignorieren.
        if ($event->other["completionstate"] != 1) {
			return;
		}

        $event_data = $event->get_data();

        $courseid = $event_data["courseid"];

        // Schauen ob das überhaupt getracked wird. Gibt es ein Curriculum im Kurs?
        $cms = get_coursemodules_in_course('curriculum', $courseid);
        if (empty($cms)) {
            return;
        }

        $common_name = $USER->username;
        if (!empty($CFG->mod_curriculum_commonname)) {
            $common_name = $CFG->mod_curriculum_commonname;
        }

        // Kommt die Aktivität in einer Kompetenzverknüpfung vor?
        $currentactivity = $event->contextinstanceid; // cmid der gegradeten Aktivität, schauen ob es in der liste der triggeractivities steht. daztugehörige triggerobjective rausfiltern.
 
        $melden = array();
        foreach ($cms as $cm) {
            $moduleinstance = $DB->get_record( 'curriculum', ['id' => $cm->instance], '*', MUST_EXIST );
            $triggeractivities = json_decode($moduleinstance->curriculum_triggeractivity, true);
            
            $index = array_search($currentactivity, $triggeractivities, true);
            // Wir wissen, dass es eine Verknüpfung gibt und welche objectives verknüpft sind.
            
            if ($index !== false) {

                $linked = $moduleinstance->curriculum_triggerobjectives;
                $linked = json_decode($linked);

                

                foreach ($triggeractivities as $key => $act) {
                    if ($act == $currentactivity) {
                        foreach ($linked[$key] as $value) {
                            if ($value !== "0") {
                                $melden[] = $value;
                            }
                        }
                    }
                }



            }
        
        }

                // Wir haben eine Array mit allen Objectives die in diesem Kurs mit diesem Trigger verbunden sind.
                // Hier gibt es keine thresholds daher alle gesammelt wegschicken.

                require_once __DIR__ . '/../lib.php';

                $bausteine = json_encode($melden);
                $postfields = [
                    "user_common_name" => '["'.$common_name.'"]',
                    "owner_common_name" => "$common_name",
                    "referenceable_id" => $bausteine,
                    "status" => "3X"
                ];

                $response = sendPostRequest(curriculum_get_token(), 'achievements', $postfields);
        */
    }
        
    // Jedes mal wenn eine neue Activity in einem Kurs angelegt wird prüfen wir ob es ein Curriculum ist.
    public static function activity_created(\core\event\course_module_created $event) {
        global $DB;
        global $SITE;

        // Ignoriere wenn nicht curriculum.
        if ($event->other['modulename'] !== 'curriculum') {
            return;
        }

        $event_data = $event->get_data();
        
        // Auslesen welche Curricula in diesem Kurs genutzt werden.
        $cms = get_coursemodules_in_course('curriculum', $event_data["courseid"]);
        if (empty($cms)) {
            return; // Keines, also fertig.
        }


        // Suche alle eingetragenen User, egal welche Rolle.
        $courseid = $event->courseid;
        $enrolled = get_enrolled_users( \context_course::instance($courseid), '', 0, 'u.id, u.username' );

        $common_names = array();
        foreach ($enrolled as $user) {
            $common_names[] = $user->username;
        }

        $cm = reset($cms); // Nur die erste interessiert uns.
		$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
		$moduleinstance = $DB->get_record('curriculum', array('id' => $cm->instance), '*', MUST_EXIST);
        $curricula = $moduleinstance->curriculum_elements;

		require_once __DIR__ . '/../lib.php';

        $postfields = [
            "users" => json_encode($common_names),
            "curricula" => json_encode([$curricula]),
            "groups" => json_encode([$course->shortname]),
            "organization" => "DE-RP-" . $SITE->shortname
        ];
        $response = sendPostRequest(curriculum_get_token(), 'moodle/users/enrol', $postfields);

    }

        
         



    
}
