<?php

defined('MOODLE_INTERNAL') || die();

    $observers = array(
		// Bei jeder Beurteilung senden wir Informationen an Curriculum.
        array(
            'eventname' => 'mod_assign\event\submission_graded',
            'callback' => 'mod_curriculum_observer::graded',
            'includefile' => '/mod/curriculum/classes/observer.php',
        ),
        // Bei jeder Einschreibung in einen Kurs senden wir Informationen an Curriculum.
        array(
            'eventname' => 'core\event\user_enrolment_created',
            'callback' => 'mod_curriculum_observer::enrolled',
            //'includefile' => '/mod/curriculum/lib.php',
            //'includefile' => '/mod/curriculum/classes/observer.php',
        ),
        // Bei jeder Ausschreibung in einem Kurs senden wir Informationen an Curriculum.
        array(
            'eventname' => 'core\event\user_enrolment_deleted',
            'callback' => 'mod_curriculum_observer::disroled',
            //'includefile' => '/mod/curriculum/lib.php',
			//'includefile' => '/mod/curriculum/classes/observer.php',
        ),
        // Bei jedem Aktivitätsabschluss prüfen wir ob Curriculum das trackt.
        array(
            'eventname' => 'core\event\course_module_completion_updated',
            'callback' => 'mod_curriculum_observer::completed',
            //'includefile' => '/mod/curriculum/lib.php',
			//'includefile' => '/mod/curriculum/classes/observer.php',
        ),
    );
