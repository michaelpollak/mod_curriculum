<?php
// This file keeps track of upgrades to
// the data module
//
// Sometimes, changes between versions involve
// alterations to database structures and other
// major things that may break installations.
//
// The upgrade function in this file will attempt
// to perform all the necessary actions to upgrade
// your older installation to the current version.
//
// If there's something it cannot do itself, it
// will tell you what you need to do.
//
// The commands in here will all be database-neutral,
// using the methods of database_manager class
//
// Please do not forget to use upgrade_set_timeout()
// before any action that may take longer time to finish.

defined('MOODLE_INTERNAL') || die();

function xmldb_curriculum_upgrade($oldversion) {
    global $CFG, $DB;

      $dbman = $DB->get_manager(); // Loads ddl manager and xmldb classes.
      if ($oldversion < 2022080804) {

        // Define field curriculum_elements to be added to curriculum.
        $table = new xmldb_table('curriculum');
        $field = new xmldb_field('curriculum_elements', XMLDB_TYPE_TEXT, null, null, null, null, null, 'introformat');

        // Conditionally launch add field curriculum_elements.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Curriculum savepoint reached.
        upgrade_mod_savepoint(true, 2022080804, 'curriculum');
    }


    if ($oldversion < 2022111101) {

      // Define fields curriculum_logbooks and kanbans to be added to curriculum.
      $table = new xmldb_table('curriculum');
      $field = new xmldb_field('logbook_elements', XMLDB_TYPE_TEXT, null, null, null, null, null, 'curriculum_elements');
      // Conditionally launch add field curriculum_elements.
      if (!$dbman->field_exists($table, $field)) {
          $dbman->add_field($table, $field);
      }

      $field = new xmldb_field('kanban_elements', XMLDB_TYPE_TEXT, null, null, null, null, null, 'logbook_elements');
      // Conditionally launch add field curriculum_elements.
      if (!$dbman->field_exists($table, $field)) {
          $dbman->add_field($table, $field);
      }

      // Curriculum savepoint reached.
      upgrade_mod_savepoint(true, 2022111101, 'curriculum');
    }

    if ($oldversion < 2022111501) {

      // Define fields curriculum_elements_areas and curriculum_elements_objectives to be added to curriculum.
      $table = new xmldb_table('curriculum');
      $field = new xmldb_field('curriculum_elements_areas', XMLDB_TYPE_TEXT, null, null, null, null, null, 'curriculum_elements');
      if (!$dbman->field_exists($table, $field)) {
          $dbman->add_field($table, $field);
      }

      $table = new xmldb_table('curriculum');
      $field = new xmldb_field('curriculum_elements_objectives', XMLDB_TYPE_TEXT, null, null, null, null, null, 'curriculum_elements_areas');
      if (!$dbman->field_exists($table, $field)) {
          $dbman->add_field($table, $field);
      }

      // Curriculum savepoint reached.
      upgrade_mod_savepoint(true, 2022111501, 'curriculum');
    }
    if ($oldversion < 2025082202) {

      // Define fields curriculum_elements_areas and curriculum_elements_objectives to be added to curriculum.
      $table = new xmldb_table('curriculum');
      $field = new xmldb_field('curriculum_triggeractivity', XMLDB_TYPE_TEXT, null, null, null, null, null, 'kanban_elements');
      if (!$dbman->field_exists($table, $field)) {
          $dbman->add_field($table, $field);
      }

      $table = new xmldb_table('curriculum');
      $field = new xmldb_field('curriculum_triggerobjectives', XMLDB_TYPE_TEXT, null, null, null, null, null, 'curriculum_triggeractivity');
      if (!$dbman->field_exists($table, $field)) {
          $dbman->add_field($table, $field);
      }
      
      
        // Define table curriculum_links to be created.
        $table = new xmldb_table('curriculum_links');

        // Adding fields to table curriculum_links.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('course', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('bausteinid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table curriculum_links.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('usermodified', XMLDB_KEY_FOREIGN, ['usermodified'], 'user', ['id']);

        // Conditionally launch create table for curriculum_links.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

      // Curriculum savepoint reached.
      upgrade_mod_savepoint(true, 2025082202, 'curriculum');
    }
    if ($oldversion < 2025112601) {

        // Define field threshold to be added to curriculum.
        $table = new xmldb_table('curriculum');
        $field = new xmldb_field('threshold', XMLDB_TYPE_TEXT, null, null, null, null, null, 'curriculum_triggerobjectives');

        // Conditionally launch add field threshold.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Curriculum savepoint reached.
        upgrade_mod_savepoint(true, 2025112601, 'curriculum');
    }
    if ($oldversion < 2026010806) {

        // Changing type of field activityid on table curriculum_links to text.
        $table = new xmldb_table('curriculum_links');
        $field = new xmldb_field('activityid', XMLDB_TYPE_TEXT, null, null, null, null, null, 'course');
        $dbman->change_field_type($table, $field);

        $field = new xmldb_field('bausteinid', XMLDB_TYPE_TEXT, null, null, null, null, null, 'activityid');
        $dbman->change_field_type($table, $field);

        // Curriculum savepoint reached.
        upgrade_mod_savepoint(true, 2026010806, 'curriculum');
    }
    if ($oldversion < 2026010807) {

        // Define field cmid to be added to curriculum_links.
        $table = new xmldb_table('curriculum_links');
        $field = new xmldb_field('cmid', XMLDB_TYPE_INTEGER, '20', null, null, null, null, 'course');

        // Conditionally launch add field cmid.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Curriculum savepoint reached.
        upgrade_mod_savepoint(true, 2026010807, 'curriculum');
    }

    // Es darf pro Anzeige nur ein Curriculum geben, die IDs sind gerade als Arrays gespeichert und sollen jetzt nur mehr integer sein.
    if ($oldversion < 2026031303) {

        $eintraege = $DB->get_records('curriculum');

        foreach ($eintraege as $eintrag) {

            $value = $eintrag->curriculum_elements;

            $decoded = json_decode($value, true);

            if (is_array($decoded)) {
                $eintrag->curriculum_elements = reset($decoded);
                $DB->update_record('curriculum', $eintrag);
            }
        }

        // Save upgrade point.
        upgrade_mod_savepoint(true, 2026031303, 'curriculum');
    }
    return true;
}
